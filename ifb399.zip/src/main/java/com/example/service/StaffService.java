package com.example.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.domain.Staff;

public interface StaffService extends IService<Staff> {
}
